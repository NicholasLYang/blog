$(document).ready(function() {
    if (document.getElementsByClassName("alert-bar")) {
        var a = $('.body')[0];
        a.style.paddingTop = "12%"
    }
});


